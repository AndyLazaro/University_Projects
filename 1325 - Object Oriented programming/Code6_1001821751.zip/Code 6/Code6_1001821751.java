package code6_1001821751;

import javax.swing.JFrame;

/**
 *
 * @author Andy Lazaro 1001821751
 */
public class Code6_1001821751
{

    public static void main(String[] args)
    {
        Password pass = new Password();
        pass.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pass.setSize(400, 200);
        pass.setVisible(true);
    }
    
}
